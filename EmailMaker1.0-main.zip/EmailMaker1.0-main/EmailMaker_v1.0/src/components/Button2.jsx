

function Button2() {
    return (
        <button type="submit" formAction="https://emailmaker-server-ohio.onrender.com/MakePreview" className="px-4 py-3 my-3 mx-3 bg-yellow-500 rounded-lg text-2xl font-semibold shadow-sm cursor-pointer hover:bg-yellow-700 hover:scale-105 transition ease-in-out text-yellow-50">
         Preview
        </button>
        
    )
} 

export default Button2
