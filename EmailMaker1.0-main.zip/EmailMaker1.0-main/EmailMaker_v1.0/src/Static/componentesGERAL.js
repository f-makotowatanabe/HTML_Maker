const componentesGERAL = [{component:"geral_hero"},{component:"geral_conteudo2col_01"},{component:"geral_conteudo2col_02"},{component:"geral_conteudo2col_03"},{component:"geral_conteudo2col_04"},{component:"geral_conteudo3col_01"},{component:"geral_conteudo3col_02"},{component:"geral_conteudo3col_03"},{component:"geral_conteudoBox_01"},{component:"geral_conteudoBox_02"},{component:"geral_conteudoBox_03"},{component:"geral_conteudoBox_04"}];

export {componentesGERAL}

