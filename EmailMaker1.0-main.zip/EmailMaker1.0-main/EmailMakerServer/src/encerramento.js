function encerramentoPadrao() {
   let encerramentoPadrao = `\n</table>\n<!--[if mso]></td></tr></table><![endif]-->\n</td></tr></table>\n</div>\n</body>\n</html>`;
   return encerramentoPadrao
  
}

function encerramentoFPM() {
   let encerramentoFPM = `</table>\n<!--[if mso]></td></tr></table><![endif]-->\n\n</td></tr></table>\n</div>\n\n\n<custom name="opencounter" type="tracking"/>\n<style> @media print{ #_two50 { background-image:url('https://paguemenos.everestengagement.com/ea/qmLIlRZvtc/?t=p&e=%%SubscriberID%%'); } } blockquote #_two50, #mailContainerBody #_two50, div.OutlookMessageHeader, table.moz-email-headers-table { background-image:url('https://paguemenos.everestengagement.com/ea/qmLIlRZvtc/?t=f&e=%%SubscriberID%%'); } </style>\n<div id='_two50'></div>\n<img id='_two50_img' src='https://paguemenos.everestengagement.com/ea/qmLIlRZvtc/?e=%%SubscriberID%%' alt="Subscriber" width='1' height='1' style='margin:0 !important; padding:0 !important; border:0 !important; height:1px !important; width:1px !important;' />\n\n\n</body>\n</html>`;
   return encerramentoFPM  
}

function encerramentoEXF() {
   let encerramentoEXF = `</table>\n<!--[if mso]></td></tr></table><![endif]-->\n\n</td></tr></table>\n</div>\n\n<custom name="opencounter" type="tracking"/>\n<style> @media print{ #_two50 { background-image:url('https://paguemenos.everestengagement.com/ea/qmLIlRZvtc/?t=p&e=%%SubscriberID%%'); } } blockquote #_two50, #mailContainerBody #_two50, div.OutlookMessageHeader, table.moz-email-headers-table { background-image:url('https://paguemenos.everestengagement.com/ea/qmLIlRZvtc/?t=f&e=%%SubscriberID%%'); } </style>\n<div id='_two50'></div>\n<img id='_two50_img' src='https://paguemenos.everestengagement.com/ea/qmLIlRZvtc/?e=%%SubscriberID%%' alt="Subscriber" width='1' height='1' style='margin:0 !important; padding:0 !important; border:0 !important; height:1px !important; width:1px !important;' />\n\n</body>\n</html>`;
   return encerramentoEXF  
}

module.exports = {encerramentoPadrao,encerramentoFPM,encerramentoEXF}