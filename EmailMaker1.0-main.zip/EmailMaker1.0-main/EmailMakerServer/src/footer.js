const footer = `</table>
<!--[if mso]></td></tr></table><![endif]-->
</td></tr></table>
</div>
</body>
</html>`

exports.HTMLbody2 = footer;